# Bu dosyada proje için özel ProGuard kuralları tanımlayabilirsiniz.
-keepclassmembers class * extends android.webkit.WebViewClient
-keepclassmembers class * extends android.webkit.WebChromeClient
