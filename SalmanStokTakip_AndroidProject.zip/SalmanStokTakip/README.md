# SALMAN ŞANTİYE STOK TAKİP — Android Projesi

Bu proje, `https://projeindir.com.tr/stok/` adresini açan tam işlevli bir
WebView uygulamasıdır (JavaScript, dosya yükleme, indirme, konum, kamera,
çevrimdışı algılama, aşağı çekerek yenileme dahil).

- **Uygulama adı:** SALMAN ŞANTİYE STOK TAKİP
- **Paket adı:** com.projeindir.salmanstok
- **Çıktı APK adı:** SalmanStokTakip.apk

## ÖNEMLİ

Bu proje bir yapay zeka ortamında (internet erişimi ve Android SDK/Gradle
olmadan) hazırlandı. Yani bu klasörde **derlenmiş bir .apk dosyası yoktur**,
sadece kaynak kodları vardır. APK'yı almak için aşağıdaki adımlardan birini
uygulamanız gerekir.

## Yöntem 0: GitHub Actions (kurulum gerektirmez, tamamen ücretsiz)

Bu proje içinde `.github/workflows/build.yml` adında hazır bir otomatik
derleme dosyası var. Yapmanız gerekenler:

1. github.com'da ücretsiz bir hesap açın (yoksa).
2. Sağ üstten **+ → New repository** ile yeni (public) bir depo oluşturun,
   örn. `SalmanStokTakip`.
3. Depo sayfasında **Add file → Upload files** deyip, bu zip'in içindeki
   TÜM dosya ve klasörleri (settings.gradle, build.gradle, app/, .github/
   klasörü dahil) sürükleyip bırakın. "Commit changes" deyin.
   - Not: `.github` gizli bir klasör gibi görünse de GitHub web
     yükleyicisi bunu doğru şekilde algılar, klasör yapısını koruyarak
     sürükleyip bırakmanız yeterli.
4. Yükleme bitince üstteki **Actions** sekmesine girin. "APK Derle"
   workflow'u otomatik başlayacak (birkaç dakika sürer).
5. İş tamamlanınca (yeşil tik ✅) ilgili çalıştırmaya tıklayın, en altta
   **Artifacts** bölümünden **SalmanStokTakip-APK** dosyasını indirin.
   İçinden çıkan `.apk` dosyasını telefonunuza aktarıp kurabilirsiniz.

Bu yöntemde Android Studio kurmanıza veya kod yazmanıza gerek yoktur —
derleme tamamen GitHub'ın sunucularında, ücretsiz olarak yapılır.

## Yöntem 1: Android Studio (önerilen, en kolay)

1. Android Studio'yu açın → **Open** → bu klasörü (`SalmanStokTakip`) seçin.
2. Android Studio "Gradle Sync" işlemini otomatik başlatacaktır. İlk
   açılışta internet bağlantınız olduğundan emin olun (bağımlılıklar ve
   Gradle 8.7 indirilecek).
3. Sync bittikten sonra üstteki menüden:
   **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. Derleme bitince sağ altta çıkan bildirimden **"locate"** linkine tıklayın
   veya doğrudan şu klasöre gidin:
   `app/build/outputs/apk/debug/SalmanStokTakip.apk`
5. Bu dosyayı telefonunuza kopyalayıp kurabilirsiniz (bilinmeyen kaynaklara
   izin vermeniz gerekebilir).

## Yöntem 2: Komut satırı (Gradle kuruluysa)

Klasörde hazır bir `gradlew` betiği yoktur (binary wrapper dosyası bu ortamda
oluşturulamadı). Eğer bilgisayarınızda Gradle kuruluysa:

```bash
cd SalmanStokTakip
gradle wrapper --gradle-version 8.7   # gradlew dosyalarını oluşturur
./gradlew assembleDebug               # SalmanStokTakip.apk üretir
```

APK şurada oluşur: `app/build/outputs/apk/debug/SalmanStokTakip.apk`

## Yayınlanabilir (release) APK için

Google Play'e yüklemeyeceğiniz sürece **debug APK yeterlidir** ve doğrudan
kurulabilir. Eğer imzalı bir release APK isterseniz, Android Studio'da:
**Build → Generate Signed Bundle / APK → APK** yolunu izleyip kendi
imzalama anahtarınızı (keystore) oluşturmanız gerekir.

## Uygulamanın yaptıkları

- `https://projeindir.com.tr/stok/` adresini WebView içinde açar.
- JavaScript, çerezler, yerel depolama (DOM storage) aktiftir — sitenin
  giriş ekranı ve dinamik verileri (saat, hava durumu, kur bilgisi vb.)
  normal şekilde çalışır.
- Form üzerinden dosya/fotoğraf yükleme desteklenir (kamera + galeri izni).
- Sitedeki indirme linkleri cihazın "İndirilenler" klasörüne kaydedilir.
- `tel:`, `mailto:`, `whatsapp:` linkleri ilgili uygulamalarla açılır.
- İnternet yoksa kullanıcıya "Tekrar Dene" ekranı gösterilir.
- Aşağı çekerek sayfayı yenileme (pull-to-refresh) desteklenir.
- Android geri tuşu, WebView geçmişinde geri gider.

## İstenirse eklenebilecekler

- Splash screen (açılış ekranı) ve gerçek PNG uygulama ikonu
- Push bildirimleri (Firebase entegrasyonu gerekir)
- Uygulama içi barkod/QR okuyucu (stok girişini hızlandırmak için)
- Offline (yerel SQLite) mod — siteye bağlı kalmadan çalışma
